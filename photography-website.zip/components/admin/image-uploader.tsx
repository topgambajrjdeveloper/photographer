"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, X } from "lucide-react"

interface Gallery {
  id: string
  title: string
  slug: string
}

export function ImageUploader() {
  const [galleries, setGalleries] = useState<Gallery[]>([])
  const [selectedGallery, setSelectedGallery] = useState("")
  const [files, setFiles] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const searchParams = useSearchParams()

  useEffect(() => {
    fetchGalleries()

    // Pre-select gallery if provided in URL
    const galleryId = searchParams.get("gallery")
    if (galleryId) {
      setSelectedGallery(galleryId)
    }
  }, [searchParams])

  const fetchGalleries = async () => {
    try {
      const response = await fetch("/api/galleries")
      if (response.ok) {
        const data = await response.json()
        setGalleries(data)
      }
    } catch (error) {
      console.error("Failed to fetch galleries:", error)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFiles((prev) => [...prev, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const uploadImages = async () => {
    if (!selectedGallery || files.length === 0) {
      toast({
        title: "Error",
        description: "Please select a gallery and at least one image",
        variant: "destructive",
      })
      return
    }

    setUploading(true)

    try {
      // In a real application, you would upload files to a storage service
      // For this demo, we'll simulate the upload process
      for (const file of files) {
        // Simulate upload delay
        await new Promise((resolve) => setTimeout(resolve, 500))

        // Create a mock URL for the uploaded image
        const mockUrl = `/placeholder.svg?height=800&width=800&query=${encodeURIComponent(file.name)}`

        // Save image record to database
        const response = await fetch("/api/images", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            url: mockUrl,
            alt: file.name.replace(/\.[^/.]+$/, ""), // Remove file extension
            galleryId: selectedGallery,
          }),
        })

        if (!response.ok) {
          throw new Error(`Failed to upload ${file.name}`)
        }
      }

      toast({
        title: "Images uploaded!",
        description: `Successfully uploaded ${files.length} images.`,
      })

      setFiles([])
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Some images couldn't be uploaded. Please try again.",
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Upload Images</h1>
        <p className="text-neutral-400 mt-1">Add images to your photography galleries</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upload Images</CardTitle>
          <CardDescription>Select a gallery and upload your images</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="gallery">Gallery</Label>
            <Select value={selectedGallery} onValueChange={setSelectedGallery}>
              <SelectTrigger>
                <SelectValue placeholder="Select a gallery" />
              </SelectTrigger>
              <SelectContent>
                {galleries.map((gallery) => (
                  <SelectItem key={gallery.id} value={gallery.id}>
                    {gallery.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="images">Images</Label>
            <div className="border-2 border-dashed border-neutral-700 rounded-lg p-8 text-center">
              <Upload className="h-12 w-12 mx-auto text-neutral-400 mb-4" />
              <p className="text-neutral-400 mb-4">Drag and drop your images here, or click to select files</p>
              <Input id="images" type="file" multiple accept="image/*" onChange={handleFileSelect} className="hidden" />
              <Button variant="outline" onClick={() => document.getElementById("images")?.click()}>
                Select Images
              </Button>
            </div>
          </div>

          {files.length > 0 && (
            <div className="space-y-2">
              <Label>Selected Images ({files.length})</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {files.map((file, index) => (
                  <div key={index} className="relative group">
                    <div className="aspect-square bg-neutral-800 rounded-lg flex items-center justify-center">
                      <span className="text-xs text-neutral-400 text-center p-2">{file.name}</span>
                    </div>
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute -top-2 -right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => removeFile(index)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Button
            onClick={uploadImages}
            disabled={uploading || !selectedGallery || files.length === 0}
            className="w-full"
          >
            {uploading ? "Uploading..." : `Upload ${files.length} Images`}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
