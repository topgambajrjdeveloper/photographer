import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

// GET /api/admin/stats - Get dashboard statistics
export async function GET() {
  const session = await auth()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const now = new Date()
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate())

    const [
      totalCategories,
      totalGalleries,
      totalImages,
      totalContacts,
      recentCategories,
      recentGalleries,
      recentImages,
      pendingContacts,
      topGalleries,
      recentGalleriesList,
    ] = await Promise.all([
      prisma.category.count(),
      prisma.gallery.count(),
      prisma.image.count(),
      prisma.contact.count(),
      prisma.category.count({
        where: { createdAt: { gte: lastMonth } },
      }),
      prisma.gallery.count({
        where: { createdAt: { gte: lastMonth } },
      }),
      prisma.image.count({
        where: { createdAt: { gte: lastMonth } },
      }),
      prisma.contact.count({
        where: { status: "PENDING" },
      }),
      prisma.gallery.findMany({
        take: 5,
        orderBy: { views: "desc" },
        include: {
          category: true,
          _count: { select: { images: true } },
        },
      }),
      prisma.gallery.findMany({
        take: 5,
        orderBy: { createdAt: "desc" },
        include: {
          category: true,
          _count: { select: { images: true } },
        },
      }),
    ])

    const totalViews = topGalleries.reduce((sum, gallery) => sum + gallery.views, 0)

    return NextResponse.json({
      totalCategories,
      totalGalleries,
      totalImages,
      totalContacts,
      totalViews,
      recentCategories,
      recentGalleries,
      recentImages,
      pendingContacts,
      topGalleries: topGalleries.map((gallery) => ({
        id: gallery.id,
        title: gallery.title,
        category: gallery.category?.name || "Uncategorized",
        views: gallery.views,
        imageCount: gallery._count.images,
      })),
      recentGalleriesList: recentGalleriesList.map((gallery) => ({
        id: gallery.id,
        title: gallery.title,
        category: gallery.category?.name || "Uncategorized",
        date: gallery.createdAt.toLocaleDateString(),
        imageCount: gallery._count.images,
      })),
    })
  } catch (error) {
    console.error("Error fetching admin stats:", error)
    return NextResponse.json({ error: "Failed to fetch statistics" }, { status: 500 })
  }
}
